/**
 * register.jsp 스크립트
 */
$(function(){
	$(":submit").click(function(e){
		e.preventDefault();
		
		
		let str = "";

		//폼 보내기
		$("form").append(str).submit();
	})
	
	
	
})













