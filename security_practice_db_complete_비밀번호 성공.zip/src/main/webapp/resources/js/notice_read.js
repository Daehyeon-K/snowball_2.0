/**
 * 
 */
$(function(){
   $(".btn-info").click(function(){
      // 수정을 시키거나 데이터로 넘어갈 필요 없으니 location.href를 이용해서 페이지 이동만
      location.href = "/user/email/noticeList";
   })
})