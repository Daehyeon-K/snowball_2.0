package com.study.dto;

import lombok.Data;

@Data
public class DeptDTO {
	private String dept_id;
	private String dept_name;
}
